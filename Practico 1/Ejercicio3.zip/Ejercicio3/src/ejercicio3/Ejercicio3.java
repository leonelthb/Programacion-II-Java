/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio3;

/**
 *
 * @author leone
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nombre = "Leonel Aballay";
        int edad = 33;
        double altura = 1.75;
        boolean estudiante = true;
        
       
        System.out.println("Mi nombre es: " + nombre);
        System.out.println("tengo " + edad + " Años");
        System.out.println("Mi altura: " + altura);
        System.out.println("Estudiante?: " + estudiante);
        
    }
    
}
