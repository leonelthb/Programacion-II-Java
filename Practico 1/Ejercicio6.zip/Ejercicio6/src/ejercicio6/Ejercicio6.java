/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio6;

/**
 *
 * @author leone
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Nombre:\n Juan Perez");
        System.out.println("Edad:\n 30 años");
        System.out.println("Direccion:\n \"Calle: False 123\" ");
        
        
    
    }
    
}
