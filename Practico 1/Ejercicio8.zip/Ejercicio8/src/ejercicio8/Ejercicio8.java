/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8;

import java.util.Scanner;

/**
 *
 * @author leone
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
      double num1, num2, resultado;
      
        System.out.println("Ingresa el dividiendo positivo: ");
        num1 = Integer.parseInt(input.nextLine());
        System.out.println("Ingresa el divisor positivo: ");
        num2 = input.nextInt();
        
        resultado = num1 / num2;
        
        System.out.println("El resultado es: " + resultado);
        
                
            
                
                
      
      
    }
    
}
