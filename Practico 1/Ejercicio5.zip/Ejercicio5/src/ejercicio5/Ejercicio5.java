/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio5;

import java.util.Scanner;

/**
 *
 * @author leone
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
      int  num1, num2;
      
      
        System.out.println("Ingresa el primer numero: ");
        num1 = Integer.parseInt(input.nextLine());
        System.out.println("Ingresa el segundo numero: ");
        num2 = input.nextInt();
        
        
        System.out.println("La suma es: " + (num1 + num2));
        System.out.println("Resta es:  " + (num1 - num2));
        System.out.println("La multiplicacion es: " + (num1 * num2));
        System.out.println("La division es: " + (double)num1 / num2);
        
        
        
        
        
        
    }
    
}
