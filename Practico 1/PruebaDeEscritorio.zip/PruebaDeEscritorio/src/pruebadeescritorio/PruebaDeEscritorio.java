/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebadeescritorio;

/**
 *
 * @author leone
 */
public class PruebaDeEscritorio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double a = 5;
        double b = 2;
        double resultado = a/b;
        System.out.println("Resultado: " + resultado);
    }
    
}
