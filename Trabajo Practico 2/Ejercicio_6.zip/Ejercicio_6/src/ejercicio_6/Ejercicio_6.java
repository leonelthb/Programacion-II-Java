
package ejercicio_6;

import java.util.Scanner;


public class Ejercicio_6 {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Contador de numeros positivos, negativos y 0");
        int num;
        int sumaP = 0;
        int sumaN = 0;
        int suma0 = 0;
        
        
        for (int i = 0; i < 10; i++) {
            System.out.println("Ingrese los numeros " + i + ":");
            num = Integer.parseInt(input.nextLine());
           
            if (num > 0) {
                sumaP =+ num;                
            } else if (num < 0) {
                sumaN += num;                
                          
            } else {
                suma0 ++;
            }
        }
        System.out.println("La suma de los numeros positivos: " + sumaP);
        System.out.println("La suma de los numeros negaivos: " + sumaN);
        System.out.println("La suma de los ceros: " + suma0);
    } // cierre main
    
}// cierre clase
