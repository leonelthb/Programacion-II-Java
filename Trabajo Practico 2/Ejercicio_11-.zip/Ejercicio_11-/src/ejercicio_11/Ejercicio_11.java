
package ejercicio_11;

import java.util.Scanner;


public class Ejercicio_11 {

    public static double DESCUENTO_ESPECIAL = 0.10;
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Calcular descuento especial");
        double precio, descuentoAplicado, descuentoDoble;
        
        
        System.out.println("Ingresa el precio: ");
        precio = Double.parseDouble(input.nextLine());
        
        calcularPrecioEspecial(precio); 
    }
    public static void calcularPrecioEspecual(double precio){ 
    double descuentoAplicado = precio * DESCUENTO_ESPECIAL;
    double precioFinal = precio * descuentoAplicado;
    
    
        System.out.println("Descuento especial aplicado: " + DESCUENTO_ESPECIAL);
        System.out.println("El precio final: " + precioFinal);
    }
    
    
}
