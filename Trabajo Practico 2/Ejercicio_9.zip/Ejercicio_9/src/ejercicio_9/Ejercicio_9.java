
package ejercicio_9;

import java.util.Scanner;


public class Ejercicio_9 {

   
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Calcular costo de envio ");
         double precio, peso, total, costoEnvio;
         String zona;
         
         System.out.println("Ingresa precio del producto: ");
         precio = Integer.parseInt(input.nextLine());
         
         System.out.println("Ingresa el peso del paquete en kg: ");
         peso = Double.parseDouble(input.nextLine());
         
         System.out.println("Ingresa la zona de envio (Internacional o nacional): ");
         zona = input.nextLine();
         
         costoEnvio = calcularCostoEnvio(peso, zona);
         System.out.println("El costo del envio es: " + costoEnvio);
         
         total = calcularTotalCompra(precio, costoEnvio);
         System.out.println("El total de pagar es: " + total);
         
         
         
    } // cierre main
    public static double calcularCostoEnvio(double peso, String zona) {
    double costo;
    if (zona.equalsIgnoreCase("Nacional")) {
        costo = 5 * peso;
    } else if (zona.equalsIgnoreCase("Internacional")) {
        costo = 10 * peso;
    } else {
        costo = 0; // zona inválida
    }
    return costo;
}

     public static double calcularTotalCompra(double precioProducto, double costoEnvio) {
        return precioProducto + costoEnvio;
    }

    
} // cierre clase
