
package ejercicio_2;

import java.util.Scanner;


public class Ejercicio_2 {

  
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Determinar cual es el numero mayor");
        int num1, num2, num3, numMayor;
        
        System.out.println("Ingresa el primer numero positivo: ");
        num1 = Integer.parseInt(input.nextLine());
        while (num1 <= 0) {
            System.out.println("Error Ingresa un numero positivo");
            num1 = Integer.parseInt(input.nextLine());
        }
        System.out.println("Ingresa el segundo numero positivo: ");
        num2 = Integer.parseInt(input.nextLine());
        while (num2 <= 0) {
            System.out.println("Error Ingresa un numero positivo");
            num2 = Integer.parseInt(input.nextLine());
        }
        System.out.println("Ingresa el tercer numero positivo: ");
        num3 = Integer.parseInt(input.nextLine());
        while (num3 <=0) {
            System.out.println("Error Ingresa un numero positivo");
            num3 = Integer.parseInt(input.nextLine());
        }
        
        numMayor = num1; 
                if (num2 > numMayor) {
                    numMayor = num2;
            
        }
                if (num3 > numMayor){
                    numMayor = num3;
                }
                
                System.out.println("El numero mayor es: " + numMayor);
    } // Cierre main
    
} //Cierre clase
