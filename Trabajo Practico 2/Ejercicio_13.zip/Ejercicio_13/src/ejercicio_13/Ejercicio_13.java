
package ejercicio_13;


public class Ejercicio_13 {

    
    public static void main(String[] args) {
       
        // decalrar el array
        double[] precios ={199.99,299.5,149.75,399.0,89.99};
        
        System.out.println("Precios Originales: ");
        mostrarPreciosRecursivo(precios, 0);
        
        precios[2] = 129.99;        
        precios[3] = 00.00;
        System.out.println("\nPrecios Modificados");
        mostrarPreciosRecursivo(precios, 0);

    } // cierre main
    public static void mostrarPreciosRecursivo(double[]precios, int indice){
    if (indice == precios.length){
    return;
            }
    
    
        System.out.println("Precios: $" + precios[indice]);
        
        mostrarPreciosRecursivo(precios, indice +1);
    }
} // cierre clase
