
package ejercicio_8;

import java.util.Scanner;


public class Ejercicio_8 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Calcular precio final con impuestos y descuentos");
        double precioBase, impuesto, descuento, precioF;

        System.out.println("Ingresa el precio: ");
        precioBase = Double.parseDouble(input.nextLine());

        System.out.println("Ingresa el impuesto en porcetaje (EJ: 10 para 10%) ");
        impuesto = Double.parseDouble(input.nextLine());

        System.out.println("Ingresa el descuento en porcentaje (EJ: 5 para 5%) ");
        descuento = Double.parseDouble(input.nextLine());

        precioF = calcularPrecioFinal(precioBase, impuesto, descuento);

        System.out.println("El precio final del producto es: " + precioF);
    }//cierre main

    private static double calcularPrecioFinal(double precioBase, double impuesto, double descuento) {

        var impuestoDecimal = impuesto / 100;
        var descuentoDecimal = descuento / 100;

        double precioFinal = precioBase + (precioBase * impuestoDecimal) - (precioBase * descuentoDecimal);

        return precioFinal;


    
    
    }
    
    
    
  
    
}//cirre clase
