
package ejercicio_10;

import java.util.Scanner;


public class Ejercicio_10 {

   
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Calcular stock");
        int nuevoStock, stockActual, cantidadVendida, cantidadRecibida;
        
        System.out.println("Ingrese el nuevo stock: ");
        stockActual = Integer.parseInt(input.nextLine());
        
        System.out.println("Ingrese la cantidad vendida: ");
        cantidadVendida = Integer.parseInt(input.nextLine());
        
        System.out.println("Ingrese la nueva cantidad recibida: ");
        cantidadRecibida = Integer.parseInt(input.nextLine());
      
        //método para calcular el nuevo stock
        nuevoStock = calcularNuevoStock(stockActual, cantidadVendida, cantidadRecibida);

        System.out.println("El nuevo stock es: " + nuevoStock);
    } // cierre main
    
        // Método que calcula el nuevo stock
         public static int calcularNuevoStock(int stockActual, int cantidadVendida, int cantidadRecibida) {
        return (stockActual - cantidadVendida) + cantidadRecibida;
         }
     
} // cierre clase
