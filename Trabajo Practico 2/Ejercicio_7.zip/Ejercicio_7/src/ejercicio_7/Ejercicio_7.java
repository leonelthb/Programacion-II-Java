
package ejercicio_7;

import java.util.Scanner;


public class Ejercicio_7 {

  
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Validacion de nota entre 0 y 10");
        int nota;
        do {   
            System.out.println("Ingresa la nota del 0 al 10");
            nota = Integer.parseInt(input.next());
             if (nota < 0 &&    nota > 10) {
                 System.out.println("ERROR ingresa una nota valida");
                
            }         
            
        } while (nota < 0 && nota > 10);
        System.out.println("Nota guardada correctamente: " + nota);
        input.close();
          
        
        
    } // Cierre de main
    
} //Cierre clase

