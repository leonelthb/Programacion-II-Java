
package ejercicio_12;

import java.util.Scanner;


public class Ejercicio_12 {

 
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
       
        System.out.println("\nArrays y Recursividad");
         System.out.println("");
        // Arrays con los precios establecidos
        double[] precios = {199.99, 299.5, 149.75, 399.0, 89.99};
        
        // Imprimir los valores
        System.out.println("Precios originales: ");
        for (double precio : precios) {
            System.out.println("Precio: $" + precio);
            
        }
        
        // modificar precio de uno de los productos
        precios[2] = 77.99;
        
        System.out.println("\nPrecios Modificados: ");
        for (double precio : precios) {
            System.out.println("Precio: $" + precio);
        }
        
       
        
        
    } // Cierre main
    
} // Cierre Clase
