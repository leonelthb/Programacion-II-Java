
package ejercicio.pkg1;

import java.util.Scanner;


public class Ejercicio1 {

   
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Tu año es Bisiesto? ");
        int anio;
              
        
        
        System.out.println("Ingresa tu año: ");
        anio = input.nextInt();
        
        // condicion con if y else con formula de calcular anio bisiesto
        if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 ==00)) {
            System.out.println(anio + " es bisiesto");
            
        } else {
            System.out.println(anio + " NO es bisiesto");
        }
        
        
        
        
        
    } // cierre main
    
} // cierre clase



// 