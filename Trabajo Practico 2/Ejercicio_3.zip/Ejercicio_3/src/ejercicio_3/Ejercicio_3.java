
package ejercicio_3;

import java.util.Scanner;


public class Ejercicio_3 {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Clasificacion de edad");
        int edad;
        
        System.out.println("Ingresa tu edad: ");
        edad = Integer.parseInt(input.nextLine());
        
         if (edad < 12) {
            System.out.println("Eres un niño");
        } else if (edad >= 12 && edad <= 17) {
            System.out.println("Eres un Adolescente");
        } else if (edad >= 18 && edad <= 59) {
            System.out.println("Eres un Adulto");
        } else {
            System.out.println("Eres un Adulto mayor");
        }
                input.close();
        } //Cierre main
        
    
} // Cierre clase
