
package ejercicio_4;

import java.util.Scanner;


public class Ejercicio_4 {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Calculadora de descuentos");
        double precio, precioFinal,descuento, valorDescuento;
        String categoria;
        
        
        System.out.println("Ingrese el precio del producto: ");
        precio = Double.parseDouble(input.nextLine());
        
        System.out.println("Ingrese la categoria de descuento A, B o C: ");
        categoria = input.nextLine().toUpperCase();
        
       if (categoria.equals("A")) {
            descuento = 0.10;
        } else if (categoria.equals("B")) {
            descuento = 0.15;
        } else if (categoria.equals("C")) {
            descuento = 0.20;
        } else {
            System.out.println("Categoría no válida.");
                       return; // termina el programa si la categoría es incorrecta
        }
       
       precioFinal = precio - (precio * descuento);
       valorDescuento = precio * descuento;

     System.out.println("Precio original: " + precio);
     System.out.println("Descuento aplicado: " + (descuento * 100) + "%");
     System.out.println("Precio final: " + precioFinal);
    
        
    } 
    
}
