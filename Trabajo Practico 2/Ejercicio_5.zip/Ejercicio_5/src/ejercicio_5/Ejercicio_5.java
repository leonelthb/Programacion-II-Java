
package ejercicio_5;

import java.util.Scanner;


public class Ejercicio_5 {

   
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Suma de Pares");
        int num;
        int suma = 0;
        
        System.out.println("Ingresa numeros (para finalizar preciona 0) ");
        num = Integer.parseInt(input.next());
        
        while (num != 0) {
            if (num % 2== 0 ) { // se verifica si es par
                suma += num;
                
            }
            System.out.println("Ingresa numeros (para finalizar preciona 0) ");
        num = Integer.parseInt(input.next());
        }
         System.out.println("La suma de los pares es: " + suma);       
                
    }
    
}
